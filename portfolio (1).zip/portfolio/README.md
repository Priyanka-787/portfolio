# Dhana Priyanka Kora – Portfolio

A simple static portfolio website (HTML + CSS, no build step).

## Run locally
Open `index.html` in your browser, or use VS Code "Live Server".

## Push to GitHub
```bash
git init
git add .
git commit -m "Add portfolio website"
git branch -M main
git remote add origin https://github.com/Priyanka-787/portfolio.git
git push -u origin main
```

## Deploy
- **GitHub Pages:** Repo Settings → Pages → Branch `main`, folder `/ (root)`.
- **Vercel:** Add New → Project → import this repo → Deploy (no settings needed).

## Edit content
All text is in `index.html`. Colours and fonts are in `css/style.css` (variables at the top).
